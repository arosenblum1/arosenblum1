# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 11:11:34 2022

@author: arose
"""

base = 'https://placedata.reddit.com/data/canvas-history/2022_place_canvas_history-0000000000{:02}.csv.gzip'

for n in range(79):
    url = base.format(n)
    print('wget {}'.format(url))