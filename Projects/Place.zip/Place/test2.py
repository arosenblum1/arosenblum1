# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 11:22:31 2022

@author: arose
"""

import sys

for line in sys.stdin:
    print(len(line))