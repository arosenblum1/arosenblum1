import sys

for line in sys.stdin:
    line = line.decode().strip().split(',')
    k = line[1]
    v = line[2:]
    outfile.write('{}\t{}\n'.format(k, v))
