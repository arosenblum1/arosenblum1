# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 14:13:53 2022

@author: arose
"""


def gi_main(num_chunks=79, download_files=False):    # "gi" short for "generate inputs"
    "Generates command line inputs for the entire project."
    print('\n')    

    # ensure inputs are run from the correct directory, and the directory is clean
    print('cd Place')
    print('rm log.txt')
    
    # Step 1 #
    # reset HDFS main directory
    print('hadoop fs -rm -r Place')
    print('hadoop fs -mkdir Place')
    
    print('\n\n\n')
    
    # Every iteration added to master aggregate file. First one just becomes the master.
    first_file = True    
    
    # File by file loop. 
    # MapReduce (MR) runs once to count from file, and again to add sums to master file.
    for n in range(num_chunks):
        print(f'python3 timer.py {n} >> log.txt')        
        MR_1st_pass(n, download_files)      
        copy_MR_output_to_local(n, first_file)
        if first_file:
            first_file = False
            print('\n\n\n')
            continue
        MR_2nd_pass()
        print('\n\n\n')



##############
### Step 2 ###
##############
def MR_1st_pass(n, download_files):
    
    file_name           = '2022_place_canvas_history-0000000000{:02}.csv'.format(n)
    
    # generate inputs
    wget_file           = 'wget https://placedata.reddit.com/data/canvas-history/{}.gzip'.format(file_name)        
    rename_file         = 'mv {}.gzip {}.gz'.format(file_name, file_name)
    unzip_file          = 'gunzip {}.gz'.format(file_name)
    record_size         = 'python3 size_reader.py chunk {} {} >> log.txt'.format(n, file_name)
    make_subdirectory   = 'hadoop fs -mkdir Place/chunk{}'.format(n)
    put_file_to_hdfs    = 'hadoop fs -put {} Place/chunk{}'.format(file_name, n)
    zip_local_file      = 'gzip {}'.format(file_name)
    run_jar_MR1         = f'hadoop jar ../hadoop-streaming-2.6.4.jar -input Place/chunk{n}/{file_name} -output Place/chunk{n}/out -mapper mapper1.py -reducer reducer1.py -file mapper1.py -file reducer1.py'
    del_file_local      = 'rm {}'.format(file_name)
    
    if download_files:
        print(wget_file)
    
    for command in rename_file, unzip_file, record_size, make_subdirectory, put_file_to_hdfs, del_file_local, run_jar_MR1:
        print(command)
    
    print()

##############
### Step 3 ###
##############
def copy_MR_output_to_local(n, first_file):
    
    file_name = 'Place/chunk{}/out/part-00000'.format(n)
    
    get_file                = 'hadoop fs -get {}'.format(file_name)
    rename_first_file       = 'mv part-00000 master.txt'.format(file_name)
    append_to_master        = 'hadoop fs -cat {} >> master.txt'.format(file_name)
    record_size             = 'python3 size_reader.py master {} master.txt >> log.txt'.format(n)
    del_subdirectory_HDFS   = 'hadoop fs -rm -r Place/chunk{}'.format(n)

    if first_file:
        print(get_file)
        print(rename_first_file)

    else:
        print(append_to_master)
    
    print(record_size)
    print(del_subdirectory_HDFS)
    print()


##############
### Step 4 ###
##############
def MR_2nd_pass():
    
    del_previous_subdir     = 'hadoop fs -rm -r Place/master'
    make_subdirectory       = 'hadoop fs -mkdir Place/master'
    put_master_to_HDFS      = 'hadoop fs -put master.txt Place/master'    
    run_jar_MR2             = 'hadoop jar ../hadoop-streaming-2.6.4.jar -input Place/master/master.txt -output Place/master/out -mapper mapper2.py -reducer reducer2.py -file mapper2.py -file reducer2.py'
    del_local_master        = 'rm master.txt'
    copy_master_to_local    = 'hadoop fs -get Place/master/master.txt'
    
    for command in del_previous_subdir, make_subdirectory, put_master_to_HDFS, run_jar_MR2, del_local_master, copy_master_to_local:
        print(command)

    print()


gi_main(download_files=True)