# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 14:13:53 2022

@author: arose
"""


def gi_main(num_chunks=79, download_files=False):    # "gi" short for "generate inputs"
    "Generates command line inputs for the entire project."
    
    open_master_directory()
    MR_1st_pass_loop(num_chunks, download_files)      # MR for MapReduce
    copy_MR_output_to_local()
    MR_2nd_pass()

##############    
### Step 1 ###
##############
def open_master_directory():
    print('hadoop fs -rm -r Place')
    print('hadoop fs -mkdir Place')

##############
### Step 2 ###
##############
def MR_1st_pass_loop(num_chunks, download_files):
    
    for n in range(num_chunks):
        
        file_name           = '2022_place_canvas_history-0000000000{:02}.csv'.format(n)
        
        wget_file           = 'wget https://placedata.reddit.com/data/canvas-history/{}.gzip'.format(file_name)        
        rename_file         = 'mv {}.gzip {}.gz'.format(file_name, file_name)
        unzip_file          = 'gunzip {}.gz'.format(file_name)
        make_subdirectory   = 'hadoop fs -mkdir Place/chunk{}'.format(n)
        put_file_to_hdfs    = 'hadoop fs -put {} Place/chunk{}'.format(file_name, n)
        zip_local_file      = 'gzip {}'.format(file_name)
        run_jar_MR1         = f'hadoop jar ../hadoop-streaming-2.6.4.jar -input Place/chunk{n}/{file_name} -output Place/chunk{n}/out -mapper mapper.py -reducer reducer.py -file mapper.py -file reducer.py'
        del_file            = 'rm {}.gz'.format(file_name)
        
        if download_files:
            print(wget_file)
        
        for command in [rename_file, unzip_file, make_subdirectory, put_file_to_hdfs, zip_local_file, run_jar_MR1]:
            print(command)
        
        if download_files:
            print(del_file)
        
        print()

##############
### Step 3 ###
##############
def copy_MR_output_to_local():
    pass

##############
### Step 4 ###
##############
def MR_2nd_pass():
    pass




gi_main(download_files=True)