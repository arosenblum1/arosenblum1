#%% load packages
import datetime
import numpy as np
import pandas as pd
from congress import Congress
import matplotlib.pyplot as plt
from api_key import api_key

#%% request data
congress = Congress(api_key)
house = congress.members.filter('house')[0]['members']
senate = congress.members.filter('senate')[0]['members']

#%% plot average age in congress over time by party


df = pd.DataFrame(house)
current_year = 2022
#start_date = pd.to_datetime(f'{year}0101')

### func to determine average age in a given congress/party
party = 'D'
n_congress = 116

def get_startyear(n_congress):
    start_year = current_year - 2*(117 - n_congress)
    return start_year

def get_avg_age(df, n_congress, party):
    df = df[df.party==party]
    df.date_of_birth = pd.to_datetime(df.date_of_birth)
    df['start_year'] = pd.to_datetime(f'{get_startyear(n_congress)}0101')
    ages = (df.start_year - df.date_of_birth).divide(pd.Timedelta(days=365))
    avg_age = ages.mean()
    return avg_age

d_av = {
        'n_congress': [],
        'party': [],
        'avg_age': []
        }

chamber = 'house'
for n_congress in range(102, 118):
    d_av['n_congress'].append(n_congress)
    d_av['n_congress'].append(n_congress)
    
    d_av['party'].append('D')
    d_av['party'].append('R')
    
    df = pd.DataFrame(
        congress.members.filter(chamber, congress=n_congress)[0]['members']
        )
    
    d_av['avg_age'].append(get_avg_age(df, n_congress, party='D'))
    d_av['avg_age'].append(get_avg_age(df, n_congress, party='R'))

df_av = pd.DataFrame(d_av)
df_av['start_year'] = get_startyear(df_av.n_congress)

df = df_av[df_av.party == 'D']
plt.plot(df.start_year,
         df.avg_age,
         color='blue')

df = df_av[df_av.party == 'R']
plt.plot(df.start_year,
         df.avg_age,
         color='red')

plt.show()


### func to plot average over time ###

# may need to define conversion between congress# and year
    # addendum: will definitely need to do this, otherwise how to tell how old?
# may also plot both house and senate side-by-side
# ^ will require to scope up one additional level

